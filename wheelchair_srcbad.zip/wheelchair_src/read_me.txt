roslaunch wheelchair_description gazebo.launch
rviz src/wheelchair_description/launch/urdf.rviz
rosrun rviz rviz -d src/wheelchair_description/launch/urdf.rviz

